import UIKit

var str = "Hello, playground"
func calculateBMI(weight : Float, height : Float) -> String{
    let bmi = weight / pow(height,2)
    let bmi_Message = "your BMI is \(bmi)"
    if bmi > 25
    {
        return "\(bmi_Message) and You are overweight"
    }
    else if bmi >= 18.5 && bmi<=25
    {
        return "\(bmi_Message) and You are of normal weight"
    }
    return "\(bmi_Message) you are underweight"
}

let firstBMI = calculateBMI(weight: 1000, height: 5.3)
print(firstBMI)

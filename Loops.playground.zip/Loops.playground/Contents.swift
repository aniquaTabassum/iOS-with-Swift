import UIKit

var arrayOfNumbers = [1,2,3,4,5]
var sum = 0
for numbers in arrayOfNumbers{
    sum = sum + numbers
}

print("the sum is \(sum)")

for i in 1...10{
    print(i)
}

print()

for i in 1..<10{
    print(i)
}

for numberForEven in arrayOfNumbers where numberForEven%2==0
{
    print(numberForEven)
}

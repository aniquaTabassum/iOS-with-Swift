import UIKit

func printFibonacci(limit : Int) {
    var firstNumber = 0
    var secondNumber = 1
    for i in 1...limit{
   
    var sum = firstNumber + secondNumber
    print(sum)
    
    firstNumber = secondNumber
    secondNumber = sum
    }
}

printFibonacci(limit: 10)

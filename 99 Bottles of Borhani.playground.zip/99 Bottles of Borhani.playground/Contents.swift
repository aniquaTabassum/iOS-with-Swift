import UIKit

var bottlesOfBorhani = 99


for i in 1...99{
    print("\(bottlesOfBorhani) bottles of Borhani on the wall, \(bottlesOfBorhani) bottles of Borhani")
    bottlesOfBorhani-=1
    print("Take one down and pass it around, \(bottlesOfBorhani) bottles of Borhani on the wall")
    print()
}
